package client;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import server.Server;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    private Client client;
    private Server server;

    @BeforeEach
    void setUp() throws IOException {
        server = new Server();
        server.start(5000);
        client = new Client();
        client.startConnection("127.0.0.1", 5000);
    }

    @AfterEach
    void tearDown() throws IOException {
        client.stopConnection();
        server.stop();
    }

    @Test
    void testSendAndReceiveMessage() throws IOException {
        client.sendMessage("Hello");
        assertEquals("Hello", server.receiveMessage());
    }

    @Test
    void testStopConnection() throws IOException {
        client.stopConnection();
        assertThrows(IOException.class, () -> client.receiveMessage());
    }
}
