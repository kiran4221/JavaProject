package server;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class ServerUI extends Application {
    private Server server;
    private TextArea messagesArea;
    private TextField inputField;

    @Override
    public void start(Stage primaryStage) {
        VBox root = new VBox();
        messagesArea = new TextArea();
        messagesArea.setEditable(false);
        inputField = new TextField();
        Button sendButton = new Button("Send");

        sendButton.setOnAction(e -> sendMessage());

        root.getChildren().addAll(messagesArea, inputField, sendButton);
        Scene scene = new Scene(root, 300, 400);
        primaryStage.setTitle("Server UI");
        primaryStage.setScene(scene);
        primaryStage.show();

        try {
            server = new Server();
            server.start(5000);
            new Thread(() -> {
                while (true) {
                    try {
                        String message = server.receiveMessage();
                        if (message != null) {
                            messagesArea.appendText("Client: " + message + "\n");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        break;
                    }
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage() {
        String message = inputField.getText();
        try {
            server.sendMessage(message);
            messagesArea.appendText("Server: " + message + "\n");
        } catch (IOException e) {
            messagesArea.appendText("Error: " + e.getMessage() + "\n");
        }
        inputField.clear();
    }

    @Override
    public void stop() throws Exception {
        server.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
