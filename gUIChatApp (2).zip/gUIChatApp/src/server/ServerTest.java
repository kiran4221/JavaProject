package server;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ServerTest {

    private Server server;

    @BeforeEach
    void setUp() throws IOException {
        server = new Server();
        server.start(5000); // Start the server on port 5000
    }

    @AfterEach
    void tearDown() throws IOException {
        server.stop();
    }

    @Test
    void testSendAndReceiveMessage() throws IOException {
        server.sendMessage("Hello");
        assertEquals("Hello", server.receiveMessage());
    }

    @Test
    void testStopConnection() throws IOException {
        server.stop();
        assertThrows(IOException.class, () -> server.receiveMessage());
    }
}
